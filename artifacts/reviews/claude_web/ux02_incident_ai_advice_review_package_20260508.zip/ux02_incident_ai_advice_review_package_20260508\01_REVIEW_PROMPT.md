﻿# RC-016 UX02 Incident Workbench Review Prompt

请评审 `/incident/CASE-2847` 在 RC-015 之后的 UX02 修正。

主看：
- `02_incident-product-desktop.png`
- `03_incident-product-mobile.png`

重点确认：
1. AI 建议来源区块是否默认折叠，不再干扰主操作路径。
2. 首屏是否不再出现 Qwen dry-run / provider stub / HOLD 输入包 / 模拟延迟 / stub 案例数 / Dry-run 输出预览 / 模型接入预览 等工程词。
3. 中文主路径是否继续满足：判断了什么、建议做什么、为什么可信、不确定性是什么、哪些动作不会自动执行。
4. 移动端是否可读，反馈触控区是否更接近可用。
5. 是否仍未看到 P1/P2/P3、Mock Fixture、Expert Mode、真实数据、secret/token/auth header、live API/connectors、生产写回或客户发布。

请输出：

```text
Decision:
  PASS | PASS_WITH_NOTES | HOLD_FOR_UI_FIXES

RC-015 closure:
  F1 ...
  F2 ...
  F3 ...
  N01 ...
  N04 ...
  N05 ...

Non-blocking notes:
  N1 ...

Next suggested product Goal:
  ...
```
